package com.flo.homework.repository

import com.flo.homework.domain.Homework
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.data.rest.core.annotation.RepositoryRestResource
import java.util.UUID

@RepositoryRestResource(collectionResourceRel = "homework", path = "homework")
interface HomeworkRestRepository : PagingAndSortingRepository<Homework, UUID> {}