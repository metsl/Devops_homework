CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

create table if not exists homework
(
    id      uuid      default uuid_generate_v4() not null primary key,
    name    VARCHAR(255)                         NOT NULL UNIQUE,
    created TIMESTAMP default current_date
);