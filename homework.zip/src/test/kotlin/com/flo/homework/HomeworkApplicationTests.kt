package com.flo.homework

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HomeworkApplicationTests {

    @Test
    fun contextLoads() {
    }

}
