rootProject.name = "Homework"
